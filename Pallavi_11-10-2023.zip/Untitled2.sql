select  * from emp;

select ename
from emp
where length(ename)=5;
/
select sal*12 as sal
from emp
order by sal desc;
/
select deptno, max(sal)
from emp
group by deptno;
/
select ename
from emp
where deptno=10 and sal > (select max(sal)
from emp
where deptno <>10);
/
select substr('oracle',2,3)
from dual;
/
select first_name,manager_id
from employees;
/
select e1.first_name,e2.first_name
from employees e1,employees e2
where e1.manager_id =e2.employee_id;
/
select count(*)
from  employees e1,employees e2
where e1.manager_id=e2.employee_id and e1.salary>e2.salary;
/
select  first_name,hire_date
from employees
where hire_date >=trunc(sysdate)-30;
/
select first_name
from employees
where first_name like '_o%';
/
select hire_date
from employees
where hire_date like '%dec%';
/
select sal*10/100+com as comm
from dual;
/
select  * 
from emp
where rownum in(5,7);
/
select replace('Hansen','Han','Nil')
from dual;
/
update employees
set last_name='Hansen'
where last_name='Nilsen';
/
