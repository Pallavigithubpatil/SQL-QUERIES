SET SERVEROUTPUT ON;

DECLARE
V_A NUMBER(10);
V_B NUMBER(10);
V_C NUMBER(10);
ONE_DIVIDE  EXCEPTION;
BEGIN
V_A:=&A;
V_B:=&B;
IF V_B=1 THEN
RAISE ONE_DIVIDE;
END IF;
V_C:=V_A/V_B;
DBMS_OUTPUT.PUT_LINE(V_C);
EXCEPTION
WHEN ZERO_DIVIDE THEN
DBMS_OUTPUT.PUT_LINE('ZERO DIVIDE');
WHEN ONE_DIVIDE THEN
DBMS_OUTPUT.PUT_LINE('ONE DIVIDE');
WHEN OTHERS THEN 
DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/
VARIABLE b_emp_salary NUMBER
BEGIN
SELECT salary INTO :b_emp_salary 
FROM employees WHERE employee_id = 101; 
END;
/
PRINT b_emp_salary
SELECT first_name, last_name
FROM employees 
WHERE salary=:b_emp_salary;

/
select * from employees;

/
DECLARE
v_emp_hiredate employees.hire_date%TYPE;
v_emp_salary employees.salary%TYPE; 
BEGIN
SELECT hire_date, salary
INTO v_emp_hiredate, v_emp_salary
FROM employees
WHERE employee_id = 100;
DBMS_OUTPUT.PUT_LINE ('Hire date is :'|| v_emp_hiredate);
DBMS_OUTPUT.PUT_LINE ('Salary is :'|| v_emp_salary);
END;
/
----------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE
v_rows_deleted VARCHAR2(30);
v_empno employees.employee_id%TYPE := 176;
BEGIN
DELETE FROM employees 
WHERE employee_id = v_empno;
v_rows_deleted := (SQL%ROWCOUNT ||
' row deleted.');
DBMS_OUTPUT.PUT_LINE (v_rows_deleted);
END;
/
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE
v_countryid locations.country_id%TYPE := 'CA';
v_loc_id locations.location_id%TYPE;
v_counter NUMBER(2) := 1;
v_new_city locations.city%TYPE := 'Montreal';
BEGIN
SELECT MAX(location_id) INTO v_loc_id FROM locations
WHERE country_id = v_countryid;
LOOP
INSERT INTO locations(location_id, city, country_id) 
VALUES((v_loc_id + v_counter), v_new_city, v_countryid);
v_counter := v_counter + 1;
EXIT WHEN v_counter > 3;
END LOOP;
END;
/
DECLARE
v_lower NUMBER := 1;
v_upper NUMBER := 100;
BEGIN
FOR i IN v_lower..v_upper LOOP
dbms_output.put_line(i);
END LOOP;
END;