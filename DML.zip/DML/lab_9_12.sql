update my_employeee1
set salary=1000
where salary <900;

select * from my_employeee1;