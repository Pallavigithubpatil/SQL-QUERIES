insert into my_employeee1(id,last_name,first_name,userid,salary)values(2,'Dancs','Betty','bdancs',860);


select * from my_employeee1;