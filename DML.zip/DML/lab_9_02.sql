create table my_employeee1(
id number(4) primary key,
last_name varchar(25),
first_name varchar(25),
userid varchar(8),
salary number(9,2)
);

