insert into my_employeee1 values(&id,&last_name,&first_name,&userid,&salary);






select * from my_employeee1