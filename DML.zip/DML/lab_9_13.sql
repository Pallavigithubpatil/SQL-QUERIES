select * from my_employeee1;

delete
from my_employeee1
where first_name='Betty'