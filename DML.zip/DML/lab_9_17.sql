
insert into my_employeee1  values(6,'Patil','Pallavi','pgpatil',50000);
commit;

select * from my_employeee1;

