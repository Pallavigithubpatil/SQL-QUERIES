
delete 
from my_employeee1;

select * from my_employeee1;

rollback



