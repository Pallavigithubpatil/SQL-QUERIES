
insert into my_employeee1  values(6,'Patil','Pallavi','pgpatil',50000);

select * from my_employeee1;

