
select id,initcap(last_name),initcap(first_name),userid,salary
from my_employeee1;
select * from my_employeee1;

