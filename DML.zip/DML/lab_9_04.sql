insert into my_employeee1 values(1,'Patel','ralph','rpatel',895);


select * from my_employeee1;