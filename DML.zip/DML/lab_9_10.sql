update my_employeee1
set last_name='Drexler'
where id=3;


select * from my_employeee1;